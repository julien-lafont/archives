Name of Mod        : The Jumbot
File Name          : jumbot24.zip
Version            : 2.4
Date               : October 27, 2000
Author             : Rich Whitehouse
E-mail             : thefatal@telefragged.com
Web Site           : http://www.telefragged.com/thefatal/

Additional Credits : Thanks to all the people who've helped me and
                     given me support, especially people like Strider
                     and news sites like the Bot Epidemic. I appreciate
                     all of the support. Thanks to Brian McClelland and
                     Adam Smith for helping test the bot and informing
                     me of various bugs. Thanks to John Crickett (author
                     of the Oak bot) for the helpful information on file
                     I/O. Thanks also to TFSoft@aol.com for solving the
                     bot milliseconds physics call problem.
INDEX
-----
1 - General information.
    1.1 - Author info.
    1.2 - Mod info.

2 - Version history.

3 - Setting up.
    3.1 - Installation and use.
    3.2 - Starting a coop game.

4 - Troubleshooting and performance issues.

5 - Custom features.
    5.1 - Custom bot config files.
    5.2 - Custom bot chat files.
    5.3 - Custom level config files.
    5.4 - A list of cvars and commands.
    5.5 - Team bot cooperation (chat ordering).

6 - Constructing waypoint (JRF) files.

7 - Bugs, etc.

8 - Copyright/legal things.


1 - GENERAL INFORMATION
-----------------------

1.1 - AUTHOR INFO
-----------------
I'm also the author of the Famkebot, Head Soccer, and many other
things.

1.2 - TYPE OF MOD 
-----------------
This is a DeathMatch, Teamplay, and Cooperative bot for Half-Life.

Programming  : All of it.
Sound        : Nope.
MDL          : Nope.
Maps         : Nope.
Graphics     : Nope.


2 - VERSION HISTORY
-------------------
2.4:
A new bot leader/squad system has been added. In teamplay games, squad
leaders will be assigned and will tell other bots in their squad what
to do by using chat commands. Players can also easilly take control of
a squad leader or the members of a squad by using the bot ordering chat
commands (listed in the readme.txt). celtic88 (over at the Bot Epidemic)
inadvertently reminded me that I wanted to add this feature a while ago.

Bots will now snipe on purpose (as an option). If bot sniping is enabled,
sniper bots will be issued randomly. Sniper bots will go after a sniper
weapon if it is on the map (the crossbow) and then go to a snipe point
and sit there sniping at enemies as long as their sniping conditions
remain acceptable (meaning they have enough health, ammo, are not in the
middle of reloading, etc).

Bots can now camp better (as an option). If bot camping is enabled,
camper bots will be issued randomly. Camper bots find powerful weapons
and/or items and camp on them by moving only within a certain distance
from the weapon or item and frequently sitting by the item and looking
at possible directions an attacker could approach from. Camping was
suggested by TriNitro.

I've added a new option, which I will refer to as the "realistic game
option". If you enable this option, it will sort of automate everything
and make things seem more like a real server. Bots will chat randomly
to each other, leave and join at random, and quite a few other things.
The cvar for this mode is bot_realgame.

A moron type bot has been created for the realistic mode. Moron bots
will be added every once in a while when realistic mode is on. These
bots use completely seperate configuration files for their names and
chat abilities, and will also tend to do horrible stupid things (some
of these things are done "accidentally on purpose").

Chat capabilities have been extended. Bots talk to each other, greet
each other, say good bye to each other, and more things which I've
forgotten about. Moron bots also utilize all of the new chat features.

Added a morons.cfg file and a exchat.cfg file, which allows the user
to customize all of the new chat options for bots and moron bots.

Bots can now better avoid snipers and other unseeable enemies by using
evasive navigation routines while under fire.

Bot hearing has been tweaked so that the bot's hearing distance is more
realistic (in accordance to that of a player's).

Higher-skilled bots can now avoid grenades, satchels, and other objects
with the flag of evilness by making more intelligent path decisions.
This can be disabled by using the newly added bot_objavoid cvar.

When friendly fire is on in teamplay, bots will make an effort to not
hit teammates in the way while engaging in combat with an enemy.

Turret usage/aim has been improved.

Lower-skilled bots will sometimes stop strafing and sit still while
shooting at their opponent. This addition was suggested by snakebite.

Added a botorders.cfg file, which holds order-acknowledgement lines for
teamplay bots (meaning what they say when you tell them to do something).
Can be edited to the will of the user.

Ledge checking has been improved, so bots will no longer go off of
ledges anywhere unless the decision to do so is made purposefully
(that means they only will if the waypoint trail says it's alright).

Bot accuracy now better factors in the movement of both the bot and
the bot's target.

A makewp_snipe command has been added to allow the user to easilly add
good sniper points to JRF files in edit mode. The way this command works
will also allow users to easilly create sniper points in existing JRF
files with very little effort and without changing any other part of
the JRF file.

The old chat file format is now obsolete. exchat.cfg is the new version
of "botchat.cfg". The new format is much more stable and easy to edit.

Got rid of a possible memory leak in the chat routine.

Got rid of a possible memory leak in the general bot info routines.
---
2.3:
Gauss jumping has been improved, and bots will use it to take
shortcuts if they have somewhere they want to be (they will gauss
jump straight up toward the turrets in doublecross instead of
taking the ladder up, for example).

Bots will now use the longjump module during straight navigation
routines if they have it, in order to cover long distances faster.

Bots know how to destroy breakable objects (such as glass, vent
covers, etc) and will do so if it is appropriate. This will allow
them to get many more places than before (they'll also go into the
vent area in stalkyard now by breaking it open with the crowbar).

The waypoint system has had a major fix-up, and the entire edit
system has had many improvements and a partial rewrite. Waypoints
can now be added and removed in the middle of trails easilly, and
you can get information about any waypoint on the level by looking
at it.

Bots now react to sound and sight when using health/suit chargers.

Fixed an overflow error happening on some levels at the start.

Many optimizations to the horrible AI (should provide a good speed
increase). Unfortunately, even when the bots only makes two traces
per frame (which is really pretty minimal), it can cut the
framerate down horribly when you've got 15 or so bots in the game.
If you would like more information on how to speed things up (in
case you aren't fortunate enough to be using a P3 1GHZ like me),
then you can take a look at the readme.txt's updated
troubleshooting and performance section.

The AI for when a bot should engage in straight combat has been
improved, so bots will have a better sense of when to run and when
to not.

Object avoidance during navigation has been improved a lot, so
bots shouldn't really get stuck at all anywhere if the JRF is done
well enough.

Combat AI has finally been improved. Bots should not get stuck on
things so much when after a target (I am sorry for not touching
that for so long).

Bots can handle broken routes. This means that if the bot cannot
reach its destination point, it will figure out a different place
to go (results in bots working much better on levels with filthy
poorly-done route files).

Added a bot_wprecalc option. This ignores all standard waypoint
stuff on level load and calculates seperate paths and trails upon
loading the waypoint file. This can help the way bots behave with
some very badly done JRF files, though it can also cause them to
behave in a less desirable way. There is also the fact that it
eats up a lot of CPU power, so it is disabled by default.

Rocket launcher usage has been improved somewhat, so bots are now
even less likely to murder themselves by shooting rockets against
walls.

The included stalkyard JRF has been redone to take advantage of
many new features.

The level is now automatically restarted after a waypoint file is
saved.

Bots will no longer get stuck on lifts and ladders while running
away from other players/bots.

The readme.txt's waypoint information section has been updated
with all the information you'll need to take advantage of the new
navigation features.
---
2.2:
Added teamplay bot ordering and teaching. You can use chatting to
order bots to do a good number of things, including watch what you
do and remember it. You can also order bots to go after specific
bots (or players) on the other team, which is a completely new
addition to the Jumbot ordering system (which was ported over from
the SH Jumbot, in case you did not know). See the readme.txt's
"Team bot cooperation" section for a list of commands and other
information.

Fixed a possible error in angle correction.

Fixed a possible error in the route distance calculation function.
---
2.1:
Various bug fixes have been made, and changes have been made to
the readme.txt regarding the additional lift/moving platform
support that was added a couple versions ago. The main fix allows
the bots to finally run at the proper speed again (a bug that was
introduced with v1.1.0.0 of HL).
---
2.0:
The bot works with Valve's stupid new patch.

I've fixed and optimized a bunch of things and got rid of some
no-longer-needed hacks that I'd made to fix old SDK problems.

Code is cleaner and marked well for easy porting to mods/other
code bases.
---
1.9:
General bot movement is now smoother and more human-like (optional
with the bot_smoothnav cvar).

Bot aiming has been tweaked to look more smooth and human-like as
well.

Moving platform/better lift support has been added.

Fixed up the horrible, horrible FOV code (which also fixed a bug
with turret usage).

Many things have been done to drastically increase the speed of
the bot (CPU-wise).

Skill 4 bots no longer have absolutely perfect accuracy (it was
beginning to annoy even me).

Bots strafe in combat more intelligently.

Bots don't get added in waypoint edit mode. Perhaps this will cut
down on the "HEY WEHN I JUMP THERE AER THINGS UNDRE ME AND TEH BOTS
R ALL STPUID WHY?????" e-mail. Yes, how I love getting e-mail from
those who do not understand what a readme.txt file is.

Fixed up the strafe-troubleshoot routine.

Fixed up tracking-of-immediate-enemy routine.

Changed method of getting items.

Fixed a possible cause for program crashing (though I don't recall
it ever actually causing a crash, it's possible it could've).
---
1.8:
Boosted the waypoint limit from 1024 to 4096 (though I don't think
you'll ever need that many on any level).

Added a "wp_vis 2" option, so that waypoints will only be drawn in
edit mode if they're already visible to you. This eliminates the
pesky "flickering" which can happen if you have a lot of waypoints
on a level. It does put a load on the processor, though, so you'll
probably notice some lag if you use it.

Compiled with MSVC++ 6.0 Pro rather than 5.0 (I don't know how much
of a difference if any this makes, but it does decrease the DLL size
a significant amount).
---
1.7:
Made it so default map CFG is executed every level right before
level configs, so level settings can be applied on top of the
default settings.

Fixed a small bug in item retrieval.

Many other bug fixes that I've forgotten about.

Added a JRF and a CFG for Gustavo16_ElimJnr.
---
1.6:
Added a mapcfgs folder. If there is a CFG with the same name as a
level in this folder, it will be executed upon loading that
level. If there is not, the program will attempt to execute the
default.cfg file in the folder. An example would be, if you have
a file called boot_camp.cfg in the folder, it will then be
executed when you load the map boot_camp. If that CFG file is not
in the folder, then default.cfg will be executed. If default.cfg
is not in the folder, nothing will be executed.

Included a JRF for apohldm8.

Included a CFG file for apohldm8 so bots will play it properly.
---
1.5:
Fixed a bunch of bugs, including one causing a crash sometimes on
level changes.

Added a wp_edit cvar to edit existing waypoint files without having
to redo them completely.

Made it so the stream for the newest waypoint in a trail is a
different color, so you don't lose your place when you go back in
edit mode.
---
1.4:
Fixed up the area favoritism code. Bots learn in real-time which
areas of the level are good for certain things (such as good items,
kill spots, and more).

Changed enemy hunting so that bots will first try to gather weapons
on the level, then hunt down enemies purposely when they become
strong (this is all done realistically with use of hearing and other
senses).

Optimized shortest-route-to-goal code. Bots can now get to any spot
on the level using the given paths in the shortest possible amount
of time.

Tracing to a point path is now more optimal and bots should not get
stuck even on poorly done JRFs.

Bots treat getting to advantage points (like high-up turrets) as
goals and will make a significant effort to get to powerful weapons
as well.

Added a bot_advp cvar to toggle bots trying to get to advantage
points on and off.

Added a bot_wppref cvar to toggle bots using waypoints to get to
good weapon and kill spots on and off.
---
1.3:
Fixed navigation more so bots don't pause so long when they mess
up on a jump point (they now use intelligent tracing to see if they
should try jumping again or not).

Tweaked skill settings slightly so lower skilled bots can't evade
as well as higher skills.

Fixed strafing more so that bots don't continue trying to strafe
into walls (should've noticed that a long time ago).

Other things I've forgotten about that you probably won't notice.
---
1.2:
Added a bot_weaprun cvar to allow users to set how bad a bot's
weapon has to be before it will run, despite what weapon it has.

Added a bot_run_worse cvar to allow users to set how much worse
a bot's weapon has to be than it's opponent's before it will run.

Fixed turret usage to work better (bots shouldn't get stuck now).

Bots now track leaders in coop as well.

Added a bot_leadsys cvar to toggle use of the "leader system" on
and off. This can be changed in real-time to call and dismiss bots
as you wish.

Fixed the old item-over-ledge code that hadn't been touched for a
very long time. It was doing bad evil things (pointcontents is a
very bad method for ledge-tracing).

Bots now use standard navigation assistance more in item retrieval,
so they stand a better chance of being able to get certain items.

"Hunt" mode is now completely disabled when running away.

Lots of other random bugfixes and code clean-ups.
---
1.1:
Fixed up and put the code back in which allows higher-skilled bots
to know when to fire through the wall with the gauss cannon (both
hard and very hard bots can take advantage of this).
---
1.0:
Fixed up tripmine avoidance to work better (bots try to get around
them rather than firing at them mindlessly).

Fixed up visibility checking in the tracking routine.

Completely rewrote waypoint code to not use entities and use a
global array instead. This should make things way more efficient,
and it will get rid of the errors some people were having with too
many edicts. This also boosts the waypoint limit up to 1024, which
should be enough for any level. Note that current waypoint files are
still completely compatible, however.

Added a wp_vis cvar for when adding waypoints. This makes the last
50 waypoints in a trail have particle streams on top of them. The
reason for this is that waypoints no longer look like crossbow bolts
and have no model, because they do not take up edict slots any longer
(pretty much the only drawback of an array system, but the particle
streams should be fine). The color of the particles is also different
depending on the type of waypoint, so you can easilly tell jumping,
crouching, and regular waypoints apart.

Optimized the size of waypoint files (no longer 20kb each no
matter what).

Fixed a bug with removing waypoints where the waypoint's data
would not get removed from the global waypoint data string.

Added to the troubleshooting section in the readme.txt.

Made an index section in the readme.txt and split everything in the
file up into numbered sections (as it's getting quite large).
---
0.98:
Finally fixed the msec problem, bots run at perfect speed at all
times (many thanks to TFSoft@aol.com).
---
0.97:
Fixed a problem in the bot's navigation which would cause them
to choose a destination far away when choosing a closer one would
be a better choice.

Tweaked the bot's enemy-finding priorities to seem more realistic.

Fixed a couple obvious flaws in the bot's visibility functions that
had gone unnoticed for many versions.
---
0.96:
Fixed the bug causing bots to not see enemies sometimes until being
shot.
---
0.95:
Fixed up enemy code to let go better when an enemy dies.

Fixed up crouching to avoid obstacles (I noticed this was
still a problem when bots began gathering around the desk
drawer area on Turkeyburgers).

Fixed a bug causing bots to crouch at inappropriate times in
combat.
---
0.91:
Fixed crashing bug with killing bots in coop mode.

Fixed a bug causing bots to not hear and sometimes not see enemies
when in random-roaming mode (what they default to when no waypoint
is in view).

Added option to have bots aim at feet with the RPG.
---
0.9:
Bots now use secondary crossbow fire if they're far enough away.

Added a bot_checkdistance cvar to allow users to set if bots
should be able to see enemies at any distance or a limited
distance (defaults to limited).

Added a bot_distance cvar to allow users to set a specific
value which determines how far a bot can see.

Various bug fixes in the AI.

Fixed a bug where pain detection would cause bots to select
bad enemies (which could actually cause crashes on some levels).

Changed a model precache problem which was probably causing
the bad index of edict error on some computers.
---
0.85:
Fixed bug with some computers still crashing (or just exiting
to the desktop) when using OpenGL or Direct3D.

Tested mapcycle options and such with the bot to make sure they
work correctly after finding an unused character array which
had memory allocated for it in the level change function. This
might be what was causing some servers to crash at level changes.
---
0.8:
Added option to have the bot's skill in the bots.cfg (this
makes it easy to have bots of different skill levels in the
same game).

Included a large_bots.cfg, which contains about 90 random
bot configurations (including individual skill settings).

Changed the jumbot.cfg file a bit so that bots are now
added when you start the game up. All you now need do is
start the mod as normal and you'll be playing with bots
before you even have to do anything.

Bots can now tell which weapons they can and can't use
while under water.

Bots can see through water that normal players can see
through.

A JRF file is now included for crossfire.

Added a bot_cheats cvar to toggle if the bot can cheat when
sv_cheats is set to 1.

Added a remwp command to remove the last waypoint you placed
in a trail while waypointing a level.

Bots will check before they jump off of tall ledges, and will
not if the ledge is too high to make up for the benefit of
jumping off.

Changed skill 3 into skill 4, added a new skill 3 setting.

Made a debug build and ran in dev mode, found and fixed a
large amount of assertion failure errors (these seemed to
be happening at points where people were reporting errors
on some systems, so I believe this release may help them).

Fixed a bug in recent versions which made head/limb shots
on bots not work.

Fixed a crashing bug that's been in recent versions.

Completely fixed the Direct3D bug (it was still crashing
in D3D after an hour or so).
---
0.71:
Fixes a bug in bot chatting, a bug in random bot adding, and
refixes the Direct3D bug.
---
0.7:
If a bot hears a player/bot in another part of the level and
feels it is prepared well enough for a fight (taking health
and such into consideration) and is not already fighting, it
will track the noise it heard in order to try to find an
enemy to engage in combat with.

Added a bot_hunt cvar to allow disabling of the bot's new
hunting ability. It is, of course, enabled by default.

Added a bot_skill cvar to set the bot's overall skill level
instead of having to set individual values. The overall skill
level can also be kept for each bot so they will have their
own skill values (this is optional).

Added to the bot's tracking AI. The bot will now track its
enemy down by searching around the spot it last saw its enemy
at.

Bots can now run away if they feel they're at a disadvantage
in combat. Bots do not view information on other clients
that real players can't normally see, and their reasoning
and logic for deciding to run away is completely real. When
running away, the bot can also try to run backwards and
navigate while firing at its enemy.

Added a bot_runaway cvar to toggle if bots are allowed to
run away from battles or not.

When running away, bots will calculate the best path to use
in order to escape their opponent.

Improved tripmine avoidance more.

Improved firing ranges in weapon management.

Snarks and hornets now work on all levels correctly (this
was actually added in v0.65 but not mentioned).

Improved random roaming more. Bots will never just sit there
anymore like they did on some levels before.

Bots can now track enemies while going after items, which
makes them less vulnerable during those times.

Added spawndelay cvar for jumbot.cfg file which delays the
bot_num spawn time for bots slightly after a level is started
(mainly for coop play, since levels only have one start and not
having a delay can cause players/bots to spawn on top of
eachother).
---
0.65:
This is a bug-fix release, mainly.
---
0.6:
Bots can now use turrets (like the ones in stalkyard and such).

Bots keep individual accuracy, FOV, etc. settings if specified by
a new console cvar.

Added an option to add "random" bots (also never chooses the same
bot twice unless it's used all the bots in a config file). This
chooses a random bot profile out of a bot profile file of any size
rather than adding bots in order.

Bots now use waypoints in the water flawlessly (as flawlessly as
on land, at least).

Added a nav_autogen cvar. If waypoints are turned off, this will
automatically generate a navigation system for the bot. This isn't
quite as good as using pre-set waypoints, but works very well for
an "on-the-fly" navigation system (for those of you that are too
lazy to waypoint the levels).

Added a wp_jumpplace cvar and a makewpj command to allow better
management of jump-waypoints.

Fixed problem with real clients being disconnected from a server
on a level change (thanks to John Cook for getting back to me on
this).

Fixed bug with random crashing at times when removing bots from
the server.

Various AI fixes and improvements.
---
0.5:
Fixed tripmine avoidance.

Added bot yaw speed option.

Bots try harder not to blow themselves up.

Fixed leader-following AI to work better.

Bots no longer ignore pain while using HEV/health chargers.

Fixed a bug in the bot's enemy-tracking AI.

Corrected a bug which was causing developer mode to generate
problems as well as causing crashes on some systems in both
dev and non-dev modes.
---
0.4:
Added waypoint option for bots to jump at certain locations.

Fixed delay which made execbots.cfg not work properly.

Added item-getting troubleshooting methods.

Fixed a bug in the waypoint code that may have been causing
bad edict errors on some systems.

Added troubleshooting routines to the scientist killing
scripts in cooperative mode for if the bot can't get to the
desired distance.

Bots now try to place tripmines strategically through the
level (though there's only so much they can do to try to
find a good place).

Bots no longer shoot their own tripmines or tripmines that
belong to teammates in teamplay mode.

Bot weapon priority numbers can now be set in the jumbot.cfg
file.

Bots will now gauss-jump to get to items they cannot normally
reach.

Made an extremely large speed increase in the advanced bot
routines. speedup 0 should provide an acceptable framerate
on most systems now.

Added "speedup 2" option to only disable the things which
take a heavy amount of CPU power. This keeps things like
edge clipping to get items and such enabled.

Added a "delayed reaction" option, which is used for enemies,
mines, etc. The first time I saw a bot kill another bot with
a tripmine, it just gave me a nice warm feeling.
---
0.35:
RPG dot bug finally fixed.

Various speed optimizations.

Added a waypoint value to the jumbot.cfg file to disable use of
waypoints.

Improved the bot's non-waypoint roaming significantly.

Added auto-adjust option for bot millisecond update value (this
is now defaulted to).

Problem with client slots not being freed over level changes is
now fixed.

Fixed bots attacking monster corpses in coop.
---
0.3:
Bots have full use of ladders now.

Bug where RPG dot stayed after bots dying is fixed.

Bots are attacked by snarks and the hornet gun now.

Hopefully fixed the problem with some systems crashing after chatting
was enabled for a while.

Fixed problem with real clients not being able to chat with eachother
while running the bot.

Fixed bug that allowed bots to chat to non-client entities.

Hopefully fixed bug that caused keeping speedup set at 0 to crash
some systems.

Bots perform better with waypoints under water.
---
0.2:
All known stability problems fixed.

Windows NT incompatibility problem fixed.

Weapon selection bug fixed (bots ignored many of the regular weapons
even if they had them).

Bots now use secondary fire much more intelligently.

Added Jumbot.cfg file to be executed on startup so that your personal
preferences do not have to be typed in each time you load the bot
(execution of the file can be disabled through a cvar).

There is now a cvar to set the name of the file which the bot's name,
model, etc. is read in through, so you can have an endless number of
bot configuration files.

Chat support is now fully working. Chat files are selectable just as
bot configuration files are.

bot_num cvar added to maintain a constant number of bots on the server.
This is useful for dedicated servers and such.

Quotes can now be used in the bots.cfg file to indicate that a name has
a space in it (e.g. "Lera Yvette" instead of Lera_Yvette).

Chat files can now have anywhere from 3 to an infinite number of lines
for each section (they are no longer limited to 30 lines each).

Added edge clipping for items, combat, etc (bots will not jump off of
uncrossable ledges after items and will not fall off of ledges while
strafing to avoid fire during combat).

Cooperative play support added. See the "STARTING A COOP GAME" section
for details on how to use it.
----
0.1:
First release. Features include standard server-side client emulation,
full weapon support, a new full level navigation system, and more.


3 - SETTING UP
--------------

3.1 - INSTALLATION AND USE
--------------------------
If you have a previous version of the Jumbot installed, then delete
your old Jumbot folder before doing anything. You may wish to back
up your existing config files and such for the bot first.

Extract the zip file WITH DIRECTORY STRUCTURE directly to your Half-Life
directory. If you did it correctly, you'll have a new "jumbot" folder
under your Half-Life folder. Now start Half-Life with the console
(-console at the command line). Once in the menu, use the custom
game option to activate the Jumbot. Now just start a regular LAN game
through the menu (note that if you want to use the bots on teams, just
set up the game to use Teamplay as you normally would) and use the console
(~ key) to enter commands and change values (which are listed below).

If there is no waypoint file for the bot, you'll need to place waypoints
yourself and save them to a file once you're happy with their placement.
See below for the various waypoint management commands and values.

Before getting into a game with the bot, you'll probably also want to
edit the jumbot.cfg file in your hl\jumbot folder and change it to fit
your own preferences.

3.2 - STARTING A COOP GAME
--------------------------
First, start a regular DM game. Now, bring down the console, and type
the following:

disconnect
deathmatch 1
coop 1
sv_cheats 1
map <mapname>

If you want to load another level, repeat the same process. <mapname>
should be the level that you want to load. However, it is important
to note that coop support was never even actually finished in
Half-Life. So, it is more than likely that you'll get errors or
crashes if you try to play on the original single player levels. I
recommend using some of the many available "scientist death maps"
or any single player level that isn't cut up into sections.

After you've started the game, you can use the coop_scikill and
coop_killmeth cvars to change how the bot behaves. Details on using
the cvars are below under "SETTINGS AND COMMANDS".


4 - TROUBLESHOOTING AND PERFORMANCE ISSUES
------------------------------------------
You should note that the Jumbot uses some fairly advanced
navigation routines that require a good amount of processor speed.
However, the bot can still get around levels quite well without the
use of those routines, so there is an option to disable them for
those of you with slower computers. Simply use the speedup cvar in
the console, which you can read more about below. Also note that
increasing the bot's thinking speed to a higher value (also done
through a cvar, see below) can take more load off of the processor
because the bot does not need to do as many calculations per second.
These settings would be optimal for both compatibility and for
performance:

waypoints 0
bot_thinkspeed 1

However, I would still recommend keeping waypoints set at 1. It
doesn't cause that much CPU power to be used up and improves
the bot's navigational ability greatly (although it does require
the level to have a JRF file for it, which you can make yourself as
shown in the waypointing section of this file).

Setting bot_wppref to 0 can also give you a good speed boost. Also
note that any extra things like gauss jumping use up extra CPU power,
so disabling them well help speed things up as well.

If you're getting crashes for any reason, make sure you have version
1.1.0.1 or later of Half-Life, and it would help to make sure you
have a JRF file for the level you're playing on as well.

If you are having any problems and have the latest version of this
bot and of Half-Life, then you've most likely edited a setting in a
way that is causing problems. I recommend deleting your Jumbot
installation and re-extracting the Jumbot zip file, and also do not
use any launchers or installers with the bot. Keep all of the
settings at their default, then try running the bot and see if that
helps.


5 - CUSTOM FEATURES
-------------------

5.1 - CUSTOM BOT CONFIG FILES
-----------------------------
The Jumbot comes with 2 custom bot configuration files. bots.cfg, and
execbots.cfg. The information in bots.cfg is read and used if
nobotcfg is not set to 1 each time a bot is added. To use execbots.cfg,
type "exec execbots.cfg" in the Half-Life console. It will set nobotcfg
to 1 and use the information in the file. Both files can be edited and
added to freely using any standard text editor.

5.2 - CUSTOM CHAT CONFIG FILES
------------------------------
exchat.cfg is the default chat file. You can open it with any text
editor and change it as you wish. The file is commented so you should
have no problems figuring out what to change.

5.3 - CUSTOM LEVEL CONFIG FILES
-------------------------------
If there is a CFG with the same name as a level in your jumbot\mapcfgs
folder, it will be executed upon loading that level. If there is not,
the program will attempt to execute the default.cfg file in the folder.
An example would be, if you have a file called boot_camp.cfg in the
folder, it will then be executed when you load the map boot_camp. If
that CFG file is not in the folder, then default.cfg will be executed.
If default.cfg is not in the folder, nothing will be executed.

5.4 - SETTINGS AND COMMANDS
---------------------------
Changing any of these variables (other than bot_num) from their original
values could cause problems. You do so at your own risk.

nostartexec (cvar): Default is 0. Setting to 1 causes the jumbot.cfg
file to not be executed at the start of each level.

addbot (command): Adds a bot into the server.

removebot (command): Removes the last created bot from the server.

bot_num (cvar): Sets a constant number of bots in the game (useful
for servers running the mod and such).

bot_random (cvar): Makes each bot added random instead of taking
information from the bot config file in the correct order (default
is 0, set to 1 to enable).

bot_ackteam (cvar): Default is 1. Setting to 0 makes bots say nothing
where they would usually acknowledge receiving teamplay orders.

bot_squads (cvar): Default is 1. Setting to 0 disables bot squads in
teamplay.

bot_snipers (cvar): Default is 1. Setting to 0 disables bot snipers.

bot_campers (cvar): Default is 1. Setting to 0 disables bot campers.

bot_realgame (cvar): Default is 0. If you set this to 1 during a level,
you MUST restart the level before changes will make a difference. See
the notes about this addition in the version history section of the
readme.txt file under 2.4 for more information.

bot_objavoid (cvar): Default is 1. Setting to 0 will disable the bot's
ability to "intelligently" avoid grenades, satchels, snarks, etc.

bot_keepsettings (cvar): Default is 0, set to 1 to enable. This
causes bots to keep the accuracy, FOV, etc. settings from the
time they're added even if you change the values later.

bot_skill (cvar): Default is 0, which uses botaccuracy, botfov,
etc. to determine the difficulty. Setting to another value causes
general difficulty settings:
1 - Easy
2 - Medium
3 - Hard
4 - Very hard

waypoints (cvar): Default is 1. Setting to 0 disables use of
waypoints.

nav_autogen (cvar): Default is 1 (enabled). This will only do
anything if waypoints is set to 0 (turned off). If waypoints is
set to 0, this will use an "on-the-fly" auto-generated navigation
system for the bots. It doesn't work as well as pre-set waypoints,
but is better than a majority of waypoint-independant navigation
systems.

bot_funcsmash (cvar): This will tell bots to look for breakable
things (glass, vent covers, etc) in front of them and smash them
apart if they find any. If the bots are playing on a level that
has any of these things, then the level should come with a map
CFG that sets bot_funcsmash to 1.

bot_wppref (cvar): Default is 1 (enabled). Setting to 0 disables
the bot's use of waypoints to get to good item and kill locations.

bot_smoothnav (cvar): Default is 1 (enabled). Setting to 0 disables
the bot's smooth movement while navigating and such.

bot_advp (cvar): Default is 1 (enabled). Setting to 0 disables the
bot's use of waypoints to get to general level advantage points
(such as turrets and other methods of destruction).

but_hunt (cvar): Default is 1 (enabled). Setting to 0 disables the
bot's ability to track enemies through the level by hearing noises
they make.

bot_runaway (cvar): Default is 1 (enabled). Setting to 0 disables
the bot's ability to run away from a battle.

botfov (cvar): Sets the bot's field of vision. Works just like the
player's "fov" cvar. Default is 90.

botusefov (cvar): Default is 1. Setting to 0 tells the bot not to
limit its view to its field of vision.

bothearing (cvar): Default is 1. Setting to 0 disables the bot's
ability to detect things by hearing them instead of viewing them.

botpain (cvar): Default is 1. Setting to 0 will disable the bot's
ability to detect an enemy by figuring out which direction it is
feeling pain from (even if it cannot hear or see its enemy).

botaccuracy (cvar): Allows you to set the accuracy of the bot. The
default is 10. The lowest is 0, which is perfect, and the highest is
160, which is extremely bad.

bot_longjump (cvar): Bots will use the longjump module (if they have
it) to get places faster in standard navigation if this is set to 1.

bot_tripmines (cvar): Enables and disables allowing bots to place
tripmines. Default is 1 (enabled).

bot_gauss (cvar): Enables and disables allowing bots to gauss jump to
get to high-up items. Default is 0 (disabled).

bot_turret (cvar): Enables and disables allowing bots to use turrets.
Default is 1 (enabled).

bot_rpgaimlow (cvar): Enables and disables bots aiming for feet with
the RPG. Default is 1 (enabled).

bot_weaprun (cvar): Sets a value which determines if a bot will run if
its weapon is a certain strength. If this is set to 0, the bot will
not run no matter how bad its weapon is. Otherwise, it will check on
the same scale as weapon priorities, which, by default, is a value
between -10 and 23. The default value for this is 9, meaning it will
run if its weapon is tripmines, grenades, or the crowbar.

bot_run_worse (cvar): Sets a value which determines if a bot will run
if its weapon is a certain number of points worse than its opponent's.
This also uses the standard weapon priority scale numbers just as the
above cvar. The default is 8, meaning that for the bot to run its
opponent's weapon must be 8 points stronger than it on the scale of
-10 to 23 (by default).

bot_leadsys (cvar): Toggles leader system for coop and teamplay on
and off. Default is 1, which is on. 0 is off.

botspeed (cvar): Allows you to increase or decrease the bot's running
speed (higher increases, negative value decreases).

bot_crowbar (cvar): Toggles the bot's use of the crowbar only on and
off. 1 is on, 0 is off. Default is 0.

bot_yawspeed (cvar): Changes how fast the bot can turn. Higher is
faster, lower is slower. Default is 25.

bot_cheats (cvar): Default is 1 (enabled). Setting to 0 disables the
bot's ability to cheat when sv_cheats is set to 1.

botmsec (cvar): Changes bot physics update speed. Default is 0, which
means to auto-adjust.

msecdiv (cvar): Value to divide with the server framerate in order to
come up with the final msec value to call the bot's physics function
with. If the bot is too fast, make this lower. If it is too slow, make
it higher.

msec_min (cvar): Minimum value the msec value can reach when botmsec
is set to auto-adjust.

msec_max (cvar): Maximum value the msec value can reach when botmsec
is set to auto-adjust.

botcfgfile (cvar): Changes the name of the file used to get bot
names, models, etc. from in your Jumbot directory. The default
is bots.cfg.

bot_distance (cvar): Sets how far the bot can see (maximum distance).
The default is 4096.

bot_checkdistance (cvar): Sets if the bot should do distance checking
or be able to see things at any distance. The default is 1. Set to 0
to allow bots to see at any distance.

botchat (cvar): Default is 0. Setting to 1 enables bot chatting.

chatfreq_died (cvar): Sets how often a bot will speak after it dies.
Should be between 0.1 and 10. 0.1 would be hardly ever, 10 would be
every time.

chatfreq_killed (cvar): Sets how often a bot will speak after it kills
someone else. Should be between 0.1 and 10. 0.1 would be hardly ever,
10 would be every time.

chatfile (cvar): Default is "botchat.cfg". This allows you to specify
the name of the file that contains the comments the bot will use to
chat. All bot chat files should be placed in the Jumbot directory
under your Half-Life directory to be used.

speedup (cvar): The default for this is 0 (disabled). When set to 1,
it will disable some of the bot's advanced navigation routines and take
a significant load off of the processor. The bots will still be able to
navigate levels well, but will not do some of the more advanced things
that they normally do in exchange for less processor usage. When set to
2, some things will be disabled while others that would be disabled with
speedup 1 remain enabled. Using speedup 2 will still give you a good
speed boost, though.

bot_ai (cvar): The default for this is 1 (enabled). Setting to 0
completely disables the bot's AI.

bot_thinkspeed (cvar): The default for this is 0.1. It can be a value
anywhere between 0 and 1. This adjusts the speed at which the bot
thinks, reacts, etc. This factors into reaction time as well as
slightly into accuracy.

bot_viewdelay (cvar): Sets whether or not the bot will delay after
noticing things. Default is 1 (enabled).

bot_angleupdate (cvar): Sets whether or not the bot will change
angles each from or when it thinks. Default is 1 (enabled).

spawndelay (cvar): Number of seconds to delay the first spawn in a
level if bot_num is greater than 0.

nobotcfg (cvar): This is 0 (disabled) by default. Setting it to 1 will
disable the use of the bots.cfg file, and you'll need to use the bot
information cvars (below) to customize the bot.

b_name (cvar): The bot being added uses this value as its name if
nobotcfg is set to 1. This is also used after the bots.cfg file
runs out of profiles.

b_model (cvar): The bot being added uses this value as its model if
nobotcfg is set to 1. This is also used after the bots.cfg file
runs out of profiles.

b_topcolor (cvar): The bot being added uses this value as its shirt
color if nobotcfg is set to 1. This is also used after the bots.cfg file
runs out of profiles.

b_bottomcolor (cvar): The bot being added uses this value as its pants
color if nobotcfg is set to 1. This is also used after the bots.cfg file
runs out of profiles.

coop_scikill (cvar): Can be a value from 0 to 2. 0 disables killing of
scientists and barneys, 1 enables scientist and barney killing with
scripted murdering, and 2 treats scientists and barneys as normal
enemies. The default is 1.

coop_killmeth (cvar): Can be a value between 0 and 5. Default is 0. If
you have coop_scikill set to 1, this will allow you to change the bot's
behaviour when killing scientists. The following values are usable:
0 - Random murder.
1 - Crouch down, shoot upwards in face with shotgun.
2 - Back away, shoot in neck or skull with crossbow.
3 - Run up to and shoot directly into stomach with magnum.
4 - Rapid fire directly into stomach with glock.
5 - Crouch down and shoot upwards in skull with magnum.

*WAYPOINT MANAGEMENT COMMANDS AND CVARS*
waypoints (cvar): Enables and disables waypoints. Default is 1 (enabled).

wp_edit (cvar): Setting this to 1 enables waypoint edit mode. If there is
a waypoint file for the level, it will be loaded in edit mode instead of
used, and you can edit with the regular waypoint management commands. After
you finish using edit mode, use writewpfile to save the changes.

wp_vis (cvar): Causes all of the waypoints placed to have particle streams
on top of them. The particle colors are also different depending on the type
of waypoint. Regular waypoints are yellow, crouch waypoints are pink, jump
waypoints are red, and the last waypoint in a trail is multi-colored. The
default for this cvar is 1 (enabled). Setting it to 2 will use the alternate
display method to eliminate flickering, but it requires more CPU power.

wp_autoplace (cvar): Default is 1. Setting to 0 will disable attempts
to automatically place waypoints behind you when you're constructing
a waypoint table to be saved to a JRF file.

wp_jumpplace (cvar): Default is 1. Setting to 0 will disable automatic
adding of a jump-waypoint each time you jump.

makewp (command): This will add a waypoint at your current location, it
is used while constructing a waypoint file for a level (see below).

makewpj (command): This will add a jump waypoint at your current location.
Each time the bot comes to a jump waypoint it will jump.

makewpe (command): This will add a special waypoint that the bot will only
move to when an object is below the point.

makewp_l (command): This will add a waypoint in the middle of a trail. Just
look at a waypoint (so that the waypoint is highlighted) while using this
command and a waypoint will be inserted into the trail after that waypoint
at your current location. You can also add a number after the command to
manually inserted a waypoint after any given waypoint ("makewp_l 53", for
example, would insert the waypoint after waypoint number 53 in the trail
if it existed, as waypoint number 54, and waypoint 54 would be pushed up
to 55, and so on).

makewpj_l (command): This command is to makewp_l as makewpj is to makewp.

makewpe_l (command): This command is to makewp_l as makewpe is to makewp.

makewp_snipe (command): This command is to create a sniper waypoint. It
requires a special syntax. The syntax is:
makewp_snipe <snipe_point#> <insert_after#> <crouch>
For example, the following would create a sniper point at your current
location which points to waypoint number 200 and is inserted in an
existing trail after point 300, and the bot will crouch at this point
while sniping:
makewp_snipe 200 300 1
Use 0 as the crouch flag if you want the bot to stand at this point while
sniping.

remwp_l (command): Works the same as makewp_l, except it's for removing
waypoints instead of inserting new ones.

remwp (command): Removes the last placed waypoint.

writewpfile (command): Use this after you've finished placing waypoints
for a level to save the waypoint data to a file for later use.

5.5 - TEAM BOT COOPERATION
--------------------------
In order for commands toward bots from players to work, the server must
have bot ordering enabled. The cvar to set that is bot_ordering. 1 is
enabled, 0 is disabled.

Commands are given to bots through chatting. To give a chat command, talk
as you normally would to other players, and say "<bot's name> <command>".
Commands can only be given to bots on your team. An example would be:

yoshiki follow

You can dress this up if you wish, as well, by perhaps saying something
along the lines of:

Yoshiki, follow me!

The examples assume the bot's name is Yoshiki. If not, substitute Yoshiki
with whatever the bot's name is. A list of commands to put in place of
follow are:

stop - Tell the bot to stop following you or to stop waiting in position.

follow - Tell the bot to follow you. If the bot is not near you, it will
try to track you down in the level when you tell it to follow you.

watch - Tell the bot to watch what you're doing and remember it. This
will only work if the bot can see you and is following you. If you fire
at a location or use a button, the bot will watch and see what you did,
then remember it for later.

position - Tell the bot to get in position to execute its current memorized
action.

turn left - If the bot is in position, this will make it turn left slightly.

turn right - Same as above, only to the right.

execute - If the bot is in position, telling it to do this will make it
carry out the memorized action.

execute loop - Execute the action until instructed to stop with a stop
command.

attack - Tells the bot to attack an enemy on the other team. You must also
specify the name of the bot on the other team. If Yoshiki is on your team
and hide is on the opposing team, then to have Yoshiki attack hide you would
say something like this:

Yoshiki, attack hide.

The word "kill" can also be used in place of "attack", if you prefer.

Those are currently all of the commands. Note that you can also give orders
to multiple bots on your team in one line. The following would work, for
example:

hide, Yoshiki, Toshi, follow me!

That should be all you need to know.


6 - CONSTRUCTING WAYPOINT (JRF) FILES
-------------------------------------
When you load up a level that doesn't have a JRF file for it in your
Jumbot\wpfiles directory, you will automatically be put in waypoint edit
mode. Above under "*WAYPOINT MANAGEMENT COMMANDS AND CVARS*" is a list of
all the waypoint-related commands, many of which you will find very
useful. When you are in edit mode, waypoints will appear as small particle
clouds. Looking at a waypoint will display information about it, as well
as highlight it so that you can use some of the available waypoint
management commands to do things with it. Here's a list of tips for
creating a good JRF:

1.  Always make sure each waypoint is visible from the previous waypoint
    and the next waypoint if it's possible.

2.  Make sure you stay crouched while placing waypoints in areas that
    require the player to crouch to avoid certain obstacles.

3.  Try not to go off any ledges that you can't climb back up.

4.  When you are making a waypoint trail through a doorway, try to place
    a waypoint close to each side of the door.

5.  Place waypoints close to buttons that need to be used, so the bots
    will know to use them.

6.  Place waypoints close to health/HEV suit rechargers if you want the
    bots to use them.

7.  Place waypoints close to breakable objects if you want the bot to
    destroy them with the crowbar.

8.  If the bot behaves oddly with a certain option enabled or disabled
    on a certain level, then remember to make a level config which will
    set that option to what you want for the level you want.

9.  When using ladders, place a waypoint at the head and foot of the
    ladder.

10. Try to place a waypoint right on top of every decent accessable weapon
    or item you see (this makes the bots more likely to be able to track
    that weapon or item through the level if they need it).

11. Remember to use makewpe points with moving platforms and with lifts
    (with lifts, place the point on the lift in the lift's starting
    position). Don't misuse the points, though, as it can result in the
    bot standing there waiting for a very long time for no reason.

12. If the bot seems to fall off of things or just not behave very well
    on a level even though the waypoints are placed well, try setting
    bot_smoothnav to 0.

13. Remember to use sniper waypoints at good spots if you want bots to
    snipe well on levels. See the documentation on the makewp_snipe command
    above for information on how to place sniper points.

After you've finished constructing your waypoint file, use the writewpfile
command to save the waypoints to a JRF file and then restart the level. The
JRF will be automatically loaded each time the level is loaded from now on.
If you don't like the job you did on the JRF and want to redo it, simply
delete it from your Jumbot\wpfiles directory and reload the level. You can
also edit the existing JRF file with the in-game edit mode (see the waypoint
management commands and cvars section for details). Each JRF file will have
the same name as the level it is for (boot_camp.bsp is boot_camp.jrf, etc).


7 - BUGS, ETC.
--------------
There are currently no bugs that I know of that are very serious.
Please don't send bug reports, since I have people to test the bot for
me under pretty much all conditions and I'll eventually find a bug
if it exists. If you're having odd obvious problems, make sure you
have the latest version of Half-Life. There may be a couple problems
around, but there's always some way around them.


8 - COPYRIGHT/PERMISSIONS
-------------------------
The bot may only be distributed if this file and all the other files that
came with it are included in the redistribution, and no money is charged
for the product being distributed. This excludes such things as video
game magazines which include a CD and things such as that, which are
permitted to include this bot (provided they meet the requirements above)
as long as they notify me before doing so and get my permission through
e-mail or some other form.

