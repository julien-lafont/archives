// Copyright (c)2000 Site Meter, Inc. 

var g_server="sm4";
var g_date=new Date();
var g_hours=0;
var g_minutes=0;
var g_r="";
var g_rtype="0";

// Get the User Agent Name
var g_agent = navigator.appName;

//function errorHandler()
//{  
//	return true; 
//}

// Install an error handler (if we can) but not on WebTV
//if (g_agent.indexOf("WebTV") == -1) 
//{
//	if (window["onerror"] != null) 
//		if (typeof(window.onerror) == "object")
//			window.onerror = errorHandler;
//}

// Get the referral for non-multi-domained-framed sites using a Netscape browser
if ((g_r == "") || (g_r == "unknown origin") || (g_r == "unknown") || (g_r == "undefined"))
	if (document["parent"] != null) 
		if (parent["document"] != null) // ACCESS ERROR HERE!
			if (parent.document["referrer"] != null) 
				if (typeof(parent.document) == "object")
				{
					g_rtype="1";
					g_r=parent.document.referrer; 
				}

// Get the referral for the current document if a framed referral wasn't found
if ((g_r == "") || (g_r == "unknown origin") || (g_r == "unknown") || (g_r == "undefined"))
	if (document["referrer"] != null) 
	{
		g_rtype="4";
		g_r = document.referrer;
	}

// Get the hours
if (g_date)
	g_hours=g_date.getHours();

// Get the minutes
if (g_date)
	g_minutes=g_date.getMinutes();

if (
	(site == 'sm4nejcpass') ||
	(site == 'sm4toyo666') ||
	(site == 'sm497') ||
	(site == 'sm4jtseabolt') ||
	(site == 'sm4fdf') ||
	(site == 'sm4satem') ||
	(site == 'sm4code') ||
	(site == 'sm4mpxnl') ||
	(site == 'sm4gv') ||
	(site == 'sm4tamilbeat') ||
	(site == 'sm4bbtvcounter') ||
	(site == 'sm4vgvvv')
	)
	 window.location="http://www.jetpad.com";

// Create the image url and write it into the page. 
document.write("<a href=\"http://" + g_server + ".sitemeter.com/");
document.write("stats.asp?site="+site+"\" target=_top>");
document.write("<img src=\"http://" + g_server + ".sitemeter.com/");
document.write("meter.asp?site="+site); 
document.write("&refer="+escape(g_r));
document.write("&hours="+g_hours);
document.write("&minutes="+g_minutes);
document.write("&rtype="+g_rtype);
document.write("\" border=0 title=\"Site Meter\"></a>");

// Is this Netscape 3.X?
//if (g_agent.indexOf("Mozilla/3.") != -1) 
	document.write("<!--");
