-- phpMyAdmin SQL Dump
-- version 2.11.5
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Dim 14 Septembre 2008 à 00:39
-- Version du serveur: 5.0.51
-- Version de PHP: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de données: `nixtee`
--

-- --------------------------------------------------------

--
-- Structure de la table `ni_alerte`
--

CREATE TABLE `ni_alerte` (
  `id_alerte` mediumint(8) NOT NULL auto_increment,
  `page` varchar(255) collate utf8_unicode_ci NOT NULL,
  `message` text collate utf8_unicode_ci NOT NULL,
  `id_membre` mediumint(5) NOT NULL,
  `ip` varchar(30) collate utf8_unicode_ci NOT NULL,
  `email` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_alerte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Contenu de la table `ni_alerte`
--


-- --------------------------------------------------------

--
-- Structure de la table `ni_avis`
--

CREATE TABLE `ni_avis` (
  `id_avis` mediumint(8) NOT NULL auto_increment,
  `id_questionnaire` mediumint(8) NOT NULL,
  `reponse` longtext collate utf8_unicode_ci NOT NULL,
  `mess_auteur` text collate utf8_unicode_ci NOT NULL,
  `identite` text collate utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(30) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_avis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Contenu de la table `ni_avis`
--


-- --------------------------------------------------------

--
-- Structure de la table `ni_buddylist`
--

CREATE TABLE `ni_buddylist` (
  `id_membre` mediumint(8) NOT NULL,
  `h` longtext collate utf8_unicode_ci NOT NULL,
  `f` longtext collate utf8_unicode_ci NOT NULL,
  `p1` longtext collate utf8_unicode_ci NOT NULL,
  `p2` longtext collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_membre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `ni_buddylist`
--

INSERT INTO `ni_buddylist` (`id_membre`, `h`, `f`, `p1`, `p2`) VALUES
(3, 'a:2:{i:0;a:2:{i:0;s:4:"qsQs";i:1;s:11:"qs.qs@qs.qs";}i:1;a:2:{i:0;s:4:"sdsd";i:1;s:13:"qsqs.qs@qs.qs";}}', 'a:7:{i:0;a:2:{i:0;s:4:"Kuku";i:1;s:12:"aaa.bb@cc.fr";}i:2;a:2:{i:0;s:3:"qsd";i:1;s:3:"qsd";}i:4;a:2:{i:0;s:3:"qsd";i:1;s:3:"qsd";}i:7;a:2:{i:0;s:5:"sdsd.";i:1;s:18:"qsd.qsdqsd@qsd.qsd";}i:8;a:2:{i:0;s:3:"qsd";i:1;s:20:"qsdqsdqsd.sd@sdsd.sd";}i:9;a:2:{i:0;s:5:"kikoo";i:1;s:11:"aa.bb@cc.fr";}i:10;a:2:{i:0;s:3:"wxc";i:1;s:15:"qsd.qsd@qsd.qsd";}}', 'a:2:{i:0;a:2:{i:0;s:4:"Keke";i:1;s:10:"aabb@cc.fr";}i:1;a:2:{i:0;s:8:"qsdqsdqs";i:1;s:17:"gfhfh.fgh@fgh.fgh";}}', 'a:1:{i:0;a:2:{i:0;s:16:"Kikoo ma belle !";i:1;s:11:"aa.bb@cc.fr";}}'),
(14, 'a:1:{i:0;a:2:{i:0;s:8:"Varsovie";i:1;s:11:"aa.bb@cc.Fr";}}', '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `ni_config`
--

CREATE TABLE `ni_config` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  `cle` varchar(30) collate utf8_unicode_ci default NULL,
  `valeur` text character set utf8,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Contenu de la table `ni_config`
--

INSERT INTO `ni_config` (`id`, `description`, `cle`, `valeur`) VALUES
(1, 'Nom du site internet', 'NOM', 'Nixtee.com : découvre ta réelle popularité'),
(2, 'Meta-tag : Description du site', 'DESCRIPTION', 'lorem ipsum dolor sit amet'),
(3, 'Meta-tag : Mots clés', 'KEYWORDS', 'Dolor sit amet'),
(4, 'Core : numéro du groupe pour les utilisateurs bannis', 'GROUPE_BAN', '9'),
(5, 'Module à afficher sur la page d''accueil', 'PAGE_DEFAUT', 'accueil'),
(6, 'Core : numéro du groupe pour les admins', 'GROUPE_ADMIN', '4'),
(7, 'Titre des pages par défaut', 'TITRE_PAGE', 'Titre des pages affiché par défaut'),
(8, 'Email sur laquelle envoyer les emails de la page contact', 'EMAIL', 'yotsumi.fx@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `ni_form_membre`
--

CREATE TABLE `ni_form_membre` (
  `id_form_membre` mediumint(8) NOT NULL auto_increment,
  `id_membre` mediumint(8) NOT NULL,
  `contenu` longtext collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `nom` varchar(255) collate utf8_unicode_ci NOT NULL,
  `prive` varchar(3) collate utf8_unicode_ci NOT NULL,
  `nb_soumis` tinyint(4) NOT NULL default '0',
  `nb_rep` tinyint(4) NOT NULL default '0',
  `note` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id_form_membre`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Contenu de la table `ni_form_membre`
--

INSERT INTO `ni_form_membre` (`id_form_membre`, `id_membre`, `contenu`, `description`, `nom`, `prive`, `nb_soumis`, `nb_rep`, `note`) VALUES
(4, 3, 'a:11:{i:0;s:21:"Titre de la catégorie";i:1;a:4:{s:13:"id_quest_type";s:2:"10";s:8:"intitule";s:2:"Q9";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:2;a:4:{s:13:"id_quest_type";s:1:"2";s:8:"intitule";s:2:"Q1";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:3;a:4:{s:13:"id_quest_type";s:1:"3";s:8:"intitule";s:2:"Q2";s:4:"type";s:6:"ouinon";s:6:"valeur";s:0:"";}i:4;a:4:{s:13:"id_quest_type";s:1:"4";s:8:"intitule";s:2:"Q3";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:5;a:4:{s:13:"id_quest_type";s:1:"5";s:8:"intitule";s:2:"Q4";s:4:"type";s:8:"textarea";s:6:"valeur";s:0:"";}i:6;s:7:"Titre 2";i:7;a:4:{s:13:"id_quest_type";s:1:"6";s:8:"intitule";s:2:"Q5";s:4:"type";s:8:"multiple";s:6:"valeur";s:58:"a:4:{i:1;s:2:"aa";i:2;s:2:"bb";i:3;s:2:"cc";i:4;s:2:"dd";}";}i:8;a:4:{s:13:"id_quest_type";s:1:"7";s:8:"intitule";s:2:"Q6";s:4:"type";s:6:"slider";s:6:"valeur";s:0:"";}i:9;a:4:{s:13:"id_quest_type";s:1:"8";s:8:"intitule";s:2:"Q7";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:10;a:4:{s:13:"id_quest_type";s:1:"9";s:8:"intitule";s:2:"Q8";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}}', 'qsd', 'qsd', 'oui', 0, 0, 0),
(5, 3, 'a:11:{i:0;s:21:"Titre de la catégorie";i:1;a:4:{s:13:"id_quest_type";s:2:"10";s:8:"intitule";s:2:"Q9";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:2;a:4:{s:13:"id_quest_type";s:1:"2";s:8:"intitule";s:2:"Q1";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:3;a:4:{s:13:"id_quest_type";s:1:"3";s:8:"intitule";s:2:"Q2";s:4:"type";s:6:"ouinon";s:6:"valeur";s:0:"";}i:4;a:4:{s:13:"id_quest_type";s:1:"4";s:8:"intitule";s:2:"Q3";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:5;a:4:{s:13:"id_quest_type";s:1:"5";s:8:"intitule";s:2:"Q4";s:4:"type";s:8:"textarea";s:6:"valeur";s:0:"";}i:6;s:7:"Titre 2";i:7;a:4:{s:13:"id_quest_type";s:1:"6";s:8:"intitule";s:2:"Q5";s:4:"type";s:8:"multiple";s:6:"valeur";s:58:"a:4:{i:1;s:2:"aa";i:2;s:2:"bb";i:3;s:2:"cc";i:4;s:2:"dd";}";}i:8;a:4:{s:13:"id_quest_type";s:1:"7";s:8:"intitule";s:2:"Q6";s:4:"type";s:6:"slider";s:6:"valeur";s:0:"";}i:9;a:4:{s:13:"id_quest_type";s:1:"8";s:8:"intitule";s:2:"Q7";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:10;a:4:{s:13:"id_quest_type";s:1:"9";s:8:"intitule";s:2:"Q8";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}}', 'qsd', 'qsd', 'oui', 0, 0, 0),
(6, 3, 'a:11:{i:0;s:21:"Titre de la catégorie";i:1;a:4:{s:13:"id_quest_type";s:2:"10";s:8:"intitule";s:2:"Q9";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:2;a:4:{s:13:"id_quest_type";s:1:"2";s:8:"intitule";s:2:"Q1";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:3;a:4:{s:13:"id_quest_type";s:1:"3";s:8:"intitule";s:2:"Q2";s:4:"type";s:6:"ouinon";s:6:"valeur";s:0:"";}i:4;a:4:{s:13:"id_quest_type";s:1:"4";s:8:"intitule";s:2:"Q3";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:5;a:4:{s:13:"id_quest_type";s:1:"5";s:8:"intitule";s:2:"Q4";s:4:"type";s:8:"textarea";s:6:"valeur";s:0:"";}i:6;s:7:"Titre 2";i:7;a:4:{s:13:"id_quest_type";s:1:"6";s:8:"intitule";s:2:"Q5";s:4:"type";s:8:"multiple";s:6:"valeur";s:58:"a:4:{i:1;s:2:"aa";i:2;s:2:"bb";i:3;s:2:"cc";i:4;s:2:"dd";}";}i:8;a:4:{s:13:"id_quest_type";s:1:"7";s:8:"intitule";s:2:"Q6";s:4:"type";s:6:"slider";s:6:"valeur";s:0:"";}i:9;a:4:{s:13:"id_quest_type";s:1:"8";s:8:"intitule";s:2:"Q7";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:10;a:4:{s:13:"id_quest_type";s:1:"9";s:8:"intitule";s:2:"Q8";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}}', 'qsd', 'qsd', 'oui', 0, 0, 0),
(7, 3, 'a:11:{i:0;s:21:"Titre de la catégorie";i:1;a:4:{s:13:"id_quest_type";s:2:"10";s:8:"intitule";s:2:"Q9";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:2;a:4:{s:13:"id_quest_type";s:1:"2";s:8:"intitule";s:2:"Q1";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:3;a:4:{s:13:"id_quest_type";s:1:"3";s:8:"intitule";s:2:"Q2";s:4:"type";s:6:"ouinon";s:6:"valeur";s:0:"";}i:4;a:4:{s:13:"id_quest_type";s:1:"4";s:8:"intitule";s:2:"Q3";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:5;a:4:{s:13:"id_quest_type";s:1:"5";s:8:"intitule";s:2:"Q4";s:4:"type";s:8:"textarea";s:6:"valeur";s:0:"";}i:6;s:7:"Titre 2";i:7;a:4:{s:13:"id_quest_type";s:1:"6";s:8:"intitule";s:2:"Q5";s:4:"type";s:8:"multiple";s:6:"valeur";s:58:"a:4:{i:1;s:2:"aa";i:2;s:2:"bb";i:3;s:2:"cc";i:4;s:2:"dd";}";}i:8;a:4:{s:13:"id_quest_type";s:1:"7";s:8:"intitule";s:2:"Q6";s:4:"type";s:6:"slider";s:6:"valeur";s:0:"";}i:9;a:4:{s:13:"id_quest_type";s:1:"8";s:8:"intitule";s:2:"Q7";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:10;a:4:{s:13:"id_quest_type";s:1:"9";s:8:"intitule";s:2:"Q8";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}}', 'qsd', 'qsd', 'oui', 0, 0, 0),
(8, 3, 'a:11:{i:0;s:21:"Titre de la catégorie";i:1;a:4:{s:13:"id_quest_type";s:2:"10";s:8:"intitule";s:2:"Q9";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:2;a:4:{s:13:"id_quest_type";s:1:"2";s:8:"intitule";s:2:"Q1";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:3;a:4:{s:13:"id_quest_type";s:1:"3";s:8:"intitule";s:2:"Q2";s:4:"type";s:6:"ouinon";s:6:"valeur";s:0:"";}i:4;a:4:{s:13:"id_quest_type";s:1:"4";s:8:"intitule";s:2:"Q3";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:5;a:4:{s:13:"id_quest_type";s:1:"5";s:8:"intitule";s:2:"Q4";s:4:"type";s:8:"textarea";s:6:"valeur";s:0:"";}i:6;s:7:"Titre 2";i:7;a:4:{s:13:"id_quest_type";s:1:"6";s:8:"intitule";s:2:"Q5";s:4:"type";s:8:"multiple";s:6:"valeur";s:58:"a:4:{i:1;s:2:"aa";i:2;s:2:"bb";i:3;s:2:"cc";i:4;s:2:"dd";}";}i:8;a:4:{s:13:"id_quest_type";s:1:"7";s:8:"intitule";s:2:"Q6";s:4:"type";s:6:"slider";s:6:"valeur";s:0:"";}i:9;a:4:{s:13:"id_quest_type";s:1:"8";s:8:"intitule";s:2:"Q7";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:10;a:4:{s:13:"id_quest_type";s:1:"9";s:8:"intitule";s:2:"Q8";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}}', 'qsdqsdqsd', 'qsdqsd', 'non', 0, 0, 0),
(9, 3, 'a:11:{i:0;s:21:"Titre de la catégorie";i:1;a:4:{s:13:"id_quest_type";s:2:"10";s:8:"intitule";s:2:"Q9";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:2;a:4:{s:13:"id_quest_type";s:1:"2";s:8:"intitule";s:2:"Q1";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:3;a:4:{s:13:"id_quest_type";s:1:"3";s:8:"intitule";s:2:"Q2";s:4:"type";s:6:"ouinon";s:6:"valeur";s:0:"";}i:4;a:4:{s:13:"id_quest_type";s:1:"4";s:8:"intitule";s:2:"Q3";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:5;a:4:{s:13:"id_quest_type";s:1:"5";s:8:"intitule";s:2:"Q4";s:4:"type";s:8:"textarea";s:6:"valeur";s:0:"";}i:6;s:7:"Titre 2";i:7;a:4:{s:13:"id_quest_type";s:1:"6";s:8:"intitule";s:2:"Q5";s:4:"type";s:8:"multiple";s:6:"valeur";s:58:"a:4:{i:1;s:2:"aa";i:2;s:2:"bb";i:3;s:2:"cc";i:4;s:2:"dd";}";}i:8;a:4:{s:13:"id_quest_type";s:1:"7";s:8:"intitule";s:2:"Q6";s:4:"type";s:6:"slider";s:6:"valeur";s:0:"";}i:9;a:4:{s:13:"id_quest_type";s:1:"8";s:8:"intitule";s:2:"Q7";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:10;a:4:{s:13:"id_quest_type";s:1:"9";s:8:"intitule";s:2:"Q8";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}}', '', '', 'non', 0, 0, 0),
(10, 3, 'a:11:{i:0;s:21:"Titre de la catégorie";i:1;a:4:{s:13:"id_quest_type";s:2:"10";s:8:"intitule";s:2:"Q9";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:2;a:4:{s:13:"id_quest_type";s:1:"2";s:8:"intitule";s:2:"Q1";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:3;a:4:{s:13:"id_quest_type";s:1:"3";s:8:"intitule";s:2:"Q2";s:4:"type";s:6:"ouinon";s:6:"valeur";s:0:"";}i:4;a:4:{s:13:"id_quest_type";s:1:"4";s:8:"intitule";s:2:"Q3";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:5;a:4:{s:13:"id_quest_type";s:1:"5";s:8:"intitule";s:2:"Q4";s:4:"type";s:8:"textarea";s:6:"valeur";s:0:"";}i:6;s:7:"Titre 2";i:7;a:4:{s:13:"id_quest_type";s:1:"6";s:8:"intitule";s:2:"Q5";s:4:"type";s:8:"multiple";s:6:"valeur";s:58:"a:4:{i:1;s:2:"aa";i:2;s:2:"bb";i:3;s:2:"cc";i:4;s:2:"dd";}";}i:8;a:4:{s:13:"id_quest_type";s:1:"7";s:8:"intitule";s:2:"Q6";s:4:"type";s:6:"slider";s:6:"valeur";s:0:"";}i:9;a:4:{s:13:"id_quest_type";s:1:"8";s:8:"intitule";s:2:"Q7";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:10;a:4:{s:13:"id_quest_type";s:1:"9";s:8:"intitule";s:2:"Q8";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}}', '', '', 'non', 0, 0, 0),
(11, 3, 'a:11:{i:0;s:21:"Titre de la catégorie";i:1;a:4:{s:13:"id_quest_type";s:2:"10";s:8:"intitule";s:2:"Q9";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:2;a:4:{s:13:"id_quest_type";s:1:"2";s:8:"intitule";s:2:"Q1";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:3;a:4:{s:13:"id_quest_type";s:1:"3";s:8:"intitule";s:2:"Q2";s:4:"type";s:6:"ouinon";s:6:"valeur";s:0:"";}i:4;a:4:{s:13:"id_quest_type";s:1:"4";s:8:"intitule";s:2:"Q3";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:5;a:4:{s:13:"id_quest_type";s:1:"5";s:8:"intitule";s:2:"Q4";s:4:"type";s:8:"textarea";s:6:"valeur";s:0:"";}i:6;s:7:"Titre 2";i:7;a:4:{s:13:"id_quest_type";s:1:"6";s:8:"intitule";s:2:"Q5";s:4:"type";s:8:"multiple";s:6:"valeur";s:58:"a:4:{i:1;s:2:"aa";i:2;s:2:"bb";i:3;s:2:"cc";i:4;s:2:"dd";}";}i:8;a:4:{s:13:"id_quest_type";s:1:"7";s:8:"intitule";s:2:"Q6";s:4:"type";s:6:"slider";s:6:"valeur";s:0:"";}i:9;a:4:{s:13:"id_quest_type";s:1:"8";s:8:"intitule";s:2:"Q7";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:10;a:4:{s:13:"id_quest_type";s:1:"9";s:8:"intitule";s:2:"Q8";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}}', '', '', 'non', 0, 0, 0),
(12, 3, 'a:11:{i:0;s:21:"Titre de la catégorie";i:1;a:4:{s:13:"id_quest_type";s:2:"10";s:8:"intitule";s:2:"Q9";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:2;a:4:{s:13:"id_quest_type";s:1:"2";s:8:"intitule";s:2:"Q1";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:3;a:4:{s:13:"id_quest_type";s:1:"3";s:8:"intitule";s:2:"Q2";s:4:"type";s:6:"ouinon";s:6:"valeur";s:0:"";}i:4;a:4:{s:13:"id_quest_type";s:1:"4";s:8:"intitule";s:2:"Q3";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}i:5;a:4:{s:13:"id_quest_type";s:1:"5";s:8:"intitule";s:2:"Q4";s:4:"type";s:8:"textarea";s:6:"valeur";s:0:"";}i:6;s:7:"Titre 2";i:7;a:4:{s:13:"id_quest_type";s:1:"6";s:8:"intitule";s:2:"Q5";s:4:"type";s:8:"multiple";s:6:"valeur";s:58:"a:4:{i:1;s:2:"aa";i:2;s:2:"bb";i:3;s:2:"cc";i:4;s:2:"dd";}";}i:8;a:4:{s:13:"id_quest_type";s:1:"7";s:8:"intitule";s:2:"Q6";s:4:"type";s:6:"slider";s:6:"valeur";s:0:"";}i:9;a:4:{s:13:"id_quest_type";s:1:"8";s:8:"intitule";s:2:"Q7";s:4:"type";s:4:"note";s:6:"valeur";s:0:"";}i:10;a:4:{s:13:"id_quest_type";s:1:"9";s:8:"intitule";s:2:"Q8";s:4:"type";s:5:"input";s:6:"valeur";s:0:"";}}', '', '', 'non', 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `ni_form_type`
--

CREATE TABLE `ni_form_type` (
  `id_form_type` mediumint(8) NOT NULL auto_increment,
  `nom` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `public` varchar(255) collate utf8_unicode_ci NOT NULL,
  `contenu` longtext collate utf8_unicode_ci NOT NULL,
  `ordre` int(4) NOT NULL default '200',
  PRIMARY KEY  (`id_form_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `ni_form_type`
--

INSERT INTO `ni_form_type` (`id_form_type`, `nom`, `description`, `public`, `contenu`, `ordre`) VALUES
(1, 'Questionnaire généraliste lite', 'Des questions trés générales pour cerner comment tes amis te perçoivent globalement.<br />\r\nIl est conseillé de n''envoyer ce questionnaire qu''aux <strong>personnes de même sexe</strong>, le questionnaire généraliste complet comprenant des questions spéciales pour le sexe opposé.\r\n', 'Pour les personnes du même sexe', 'a:11:{i:0;s:21:"Titre de la catégorie";i:1;i:10;i:2;i:2;i:3;i:3;i:4;i:4;i:5;i:5;i:6;s:7:"Titre 2";i:7;i:6;i:8;i:7;i:9;i:8;i:10;i:9;}', 1);

-- --------------------------------------------------------

--
-- Structure de la table `ni_membres`
--

CREATE TABLE `ni_membres` (
  `id_membre` mediumint(8) NOT NULL auto_increment,
  `cle` varchar(20) collate utf8_unicode_ci NOT NULL,
  `groupe` tinyint(1) NOT NULL,
  `ip` varchar(30) collate utf8_unicode_ci NOT NULL,
  `activite` datetime NOT NULL,
  `pseudo` varchar(50) collate utf8_unicode_ci NOT NULL,
  `pass` varchar(50) collate utf8_unicode_ci NOT NULL,
  `email` varchar(100) collate utf8_unicode_ci NOT NULL,
  `nb_avis` tinyint(4) NOT NULL default '0',
  `note` float NOT NULL default '0',
  `nom` varchar(50) collate utf8_unicode_ci NOT NULL,
  `prenom` varchar(50) collate utf8_unicode_ci NOT NULL,
  `ville` varchar(50) collate utf8_unicode_ci NOT NULL,
  `pays` varchar(50) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `date_naiss` date NOT NULL,
  `site` varchar(255) collate utf8_unicode_ci NOT NULL,
  `photo` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_membre`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `ni_membres`
--

INSERT INTO `ni_membres` (`id_membre`, `cle`, `groupe`, `ip`, `activite`, `pseudo`, `pass`, `email`, `nb_avis`, `note`, `nom`, `prenom`, `ville`, `pays`, `description`, `date_naiss`, `site`, `photo`) VALUES
(3, 'oOtDTuyn', 1, '127.0.0.1', '0000-00-00 00:00:00', 'yotsumi', 'yodCpUSHGaxhY', 'aa.bb@cc.fr', 0, 0, '', '', '', '', '', '0000-00-00', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `ni_quest_type`
--

CREATE TABLE `ni_quest_type` (
  `id_quest_type` mediumint(8) NOT NULL auto_increment,
  `intitule` varchar(255) collate utf8_unicode_ci NOT NULL,
  `type` varchar(50) collate utf8_unicode_ci NOT NULL,
  `valeur` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_quest_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Contenu de la table `ni_quest_type`
--

INSERT INTO `ni_quest_type` (`id_quest_type`, `intitule`, `type`, `valeur`) VALUES
(2, 'Q1', 'note', ''),
(3, 'Q2', 'ouinon', ''),
(4, 'Q3', 'input', ''),
(5, 'Q4', 'textarea', ''),
(6, 'Q5', 'multiple', 'a:4:{i:1;s:2:"aa";i:2;s:2:"bb";i:3;s:2:"cc";i:4;s:2:"dd";}'),
(7, 'Q6', 'slider', ''),
(8, 'Q7', 'note', ''),
(9, 'Q8', 'input', ''),
(10, 'Q9', 'input', '');
